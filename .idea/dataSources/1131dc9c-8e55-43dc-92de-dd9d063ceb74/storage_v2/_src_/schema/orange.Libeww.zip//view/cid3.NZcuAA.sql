create view cid3 as
  select `orange`.`tb_category`.`parent_id` AS `parent_id`
  from `orange`.`tb_category`
  group by `orange`.`tb_category`.`parent_id`;

